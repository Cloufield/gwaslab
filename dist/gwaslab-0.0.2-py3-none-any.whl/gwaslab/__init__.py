from gwaslab.getsig import getsig
from gwaslab.manhattan import mplot
from gwaslab.qqplot import qqplot
from gwaslab.qqplot import gc