# gwaslab
A collection of handy python scripts for GWAS.
